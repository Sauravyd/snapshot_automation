#!/usr/bin/env bash
# snapshot_cleanup_scheduled.sh
# Deletes ONLY snapshots having BOTH:
#   AutomatedBackup=true  AND  (age_in_days >= RetentionDays tag)
# Supports:
#   --dry-run  (default)  → only prints table
#   --run      → really deletes
#   --rg RG    → optional filter by RG

set -euo pipefail

MODE="dry-run"
RG_FILTER=""
LOGFILE=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --run) MODE="run"; shift ;;
    --rg)  RG_FILTER="$2"; shift 2 ;;
    --log) LOGFILE="$2"; shift 2 ;;
    *)
      echo "Usage: $0 [--run] [--rg RG] [--log logfile]"
      exit 1 ;;
  esac
done

# ─────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────
mkdir -p snapshot_logs
if [[ -z "${LOGFILE:-}" ]]; then
  LOGFILE="snapshot_logs/cleanup-$(date +%Y%m%d-%H%M%S).log"
fi

echo "Starting cleanup: $(date -u)" | tee -a "$LOGFILE"
echo "Mode: $MODE" | tee -a "$LOGFILE"

# ─────────────────────────────────────────────────────
# Get snapshots (subscription-wide OR only from RG)
# ─────────────────────────────────────────────────────
if [[ -n "$RG_FILTER" ]]; then
  echo "Fetching snapshots from RG: $RG_FILTER" | tee -a "$LOGFILE"
  az snapshot list -g "$RG_FILTER" -o json > /tmp/snaps.json
else
  echo "Fetching all subscription snapshots..." | tee -a "$LOGFILE"
  az snapshot list -o json > /tmp/snaps.json
fi

# ─────────────────────────────────────────────────────
# Python analysis + deletion (only in --run)
# ─────────────────────────────────────────────────────
python3 - "$LOGFILE" "$MODE" << 'EOF'
import json, datetime, sys, subprocess

logfile = sys.argv[1]
mode    = sys.argv[2]

def log(msg):
    print(msg)
    with open(logfile, "a") as f:
        f.write(msg + "\n")

# Load JSON
try:
    with open("/tmp/snaps.json") as f:
        snaps = json.load(f)
except Exception as e:
    log(f"ERROR loading JSON: {e}")
    sys.exit(1)

now = datetime.datetime.now(datetime.timezone.utc)
delete_count = 0

# Print table for dry-run
if mode == "dry-run":
    log("\n📌 DRY-RUN — SNAPSHOT CHECK")
    log("%-40s %-20s %-12s %-6s %-6s" % ("NAME", "RG", "RETENTION", "AGE", "DELETE?"))
    log("-" * 95)

for s in snaps:
    tags = s.get("tags", {})
    if not tags:
        continue

    # Must have AutomatedBackup=true
    auto = str(tags.get("AutomatedBackup", "")).lower() in ("true", "1", "yes")
    if not auto:
        continue

    # RetentionDays tag
    try:
        retention = int(tags.get("RetentionDays", "14"))
    except:
        retention = 14

    # Age calculation
    created_iso = s.get("timeCreated")
    if not created_iso:
        continue

    created = datetime.datetime.fromisoformat(created_iso.replace("Z", "+00:00"))
    age = (now - created).days

    eligible = age >= retention
    rg = s.get("resourceGroup")
    name = s.get("name")

    if mode == "dry-run":
        mark = "YES" if eligible else "NO"
        log("%-40s %-20s %-12s %-6s %-6s" % (name, rg, retention, age, mark))

    if eligible and mode == "run":
        log(f"DELETE: {name} (age {age} >= {retention})")
        subprocess.run(["az", "snapshot", "delete", "-g", rg, "-n", name], check=False)
        delete_count += 1

if mode == "run":
    log(f"\n✔ Deleted {delete_count} snapshots.")
else:
    log("\n✔ DRY RUN ONLY — NO DELETIONS PERFORMED")

log("Cleanup complete.")
EOF

echo "Logfile: $LOGFILE"
